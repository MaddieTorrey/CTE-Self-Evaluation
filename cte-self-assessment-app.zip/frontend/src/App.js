import React, { useState } from "react";
import axios from "axios";
import "./App.css";

const yesNoQuestions = [
  "Have you played contact sports (e.g., football, hockey, boxing) for multiple years?",
  "Do you have memory loss (especially recent events)?",
  "Do you have trouble focusing or concentrating?",
  "Do you struggle with making decisions or controlling impulses?",
  "Have you experienced personality changes (irritability, aggression)?",
  "Do you experience mood swings or outbursts?",
  "Do you have feelings of depression or hopelessness?",
  "Have you ever had suicidal thoughts or tendencies?",
  "Do you have balance problems or unsteady walking?",
  "Do you experience tremors or shaking in limbs?",
  "Have you had persistent or recurring headaches?"
];

const scaleQuestions = [
  "On a scale of 1 to 10, how severe is your anxiety?",
  "On a scale of 1 to 10, how often do you experience dizziness?",
  "On a scale of 1 to 10, how would you rate your judgment issues?",
  "On a scale of 1 to 10, how bad is your speech difficulty?",
  "On a scale of 1 to 10, how often do you feel emotionally unstable?",
  "On a scale of 1 to 10, how severe is your chronic pain (e.g., neck, back, joints)?",
  "On a scale of 1 to 10, how often do you experience headaches or migraines?",
  "On a scale of 1 to 10, how sensitive are you to light or sound?",
  "On a scale of 1 to 10, how disrupted is your sleep due to pain?",
  "On a scale of 1 to 10, how reliant are you on medication for managing physical or mental symptoms?"
];

function App() {
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [result, setResult] = useState(null);

  const handleInputChange = (question, value) => {
    setAnswers(prev => ({ ...prev, [question]: value }));
  };

  const handleSubmit = async () => {
    try {
      const response = await axios.post("http://localhost:5000/api/submit", { answers });
      setResult(response.data);
      setSubmitted(true);
    } catch (err) {
      console.error("Error submitting assessment:", err);
    }
  };

  return (
    <div className="app-container">
      <h1>CTE Self-Assessment</h1>

      {!submitted ? (
        <>
          {yesNoQuestions.map((q, idx) => (
            <div key={idx} className="question-block">
              <label>{q}</label>
              <select onChange={(e) => handleInputChange(q, e.target.value)}>
                <option value="">Select</option>
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </div>
          ))}

          {scaleQuestions.map((q, idx) => (
            <div key={idx} className="question-block">
              <label>{q}</label>
              <input
                type="number"
                min="1"
                max="10"
                onChange={(e) => handleInputChange(q, Number(e.target.value))}
              />
            </div>
          ))}

          <button onClick={handleSubmit}>Submit Assessment</button>
        </>
      ) : (
        result && (
          <div className="result-block">
            <h2>Assessment Results</h2>
            <p><strong>Symptom Score:</strong> {result.score}</p>
            <p><strong>Risk Level:</strong> {result.risk}</p>
            <p><strong>Estimated Probability of CTE:</strong> {(result.probability * 100).toFixed(1)}%</p>
            <p className="note">⚠️ Note: This tool is for educational purposes only and not a diagnosis.</p>
          </div>
        )
      )}
    </div>
  );
}

export default App;
