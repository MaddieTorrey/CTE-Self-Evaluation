# CTE Self-Assessment App

This is a React-based self-assessment tool to evaluate symptoms potentially related to Chronic Traumatic Encephalopathy (CTE).

## Features
- Interactive Yes/No and scale-based questionnaire
- Calculates total symptom score and estimates CTE risk
- Designed for future integration with a backend API for history tracking

## Getting Started
To run locally:

```bash
cd frontend
npm install
npm start
```

## License
For educational purposes only. Not a medical diagnosis tool.
